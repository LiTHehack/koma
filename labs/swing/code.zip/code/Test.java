// ===================================================================
// fil:    ~\tnm040\lab\lab1\Test.java
// anm:    enkelt testprogram f�r klasserna Person och Register
// skapad: 2013-06-10 / janpe
// �ndrad: 2014-09-11 / klaes
// ===================================================================

public class Test
{
    public static void main(String[] args)
    {
        Person  p, q;
        Register reg = new Register();

        // l�s in register fr�n angiven fil

        if (reg.open("reg.txt"))
        {
            System.out.println("File reg.txt opened");
        }
        else
        {
            System.out.println("Can't open file reg.txt");
            System.exit(1);
        }

        // s�k namn f�r person med givet nummer

        p = reg.findName(new Person(null, null, "0111-10729"));

        if (p != null)
        {
            System.out.println("\nName = " + p.getFirstName() + " " + p.getLastName());
        }
        else
        {
            System.out.println("\nUnknown number");
        }

        // s�k nummer f�r person med givet namn

        p = reg.findPhone(new Person("Pia", "Piano", null));

        if (p != null)
        {
            System.out.println("\nNumber = " + p.getPhone());
        }
        else
        {
            System.out.println("\nUnknown name");
        }

        // s�tt in person med givet namn och nummer i registret

        p = new Person("James", "Bond", "007");

        if (reg.insert(p))
        {
            System.out.println("\nPerson inserted");
        }
        else
        {
            System.out.println("\nCan't insert person");
        }

        // ta bort person med givet namn och nummer i registret

        p = new Person("Kalle", "Anka", "0123-123123");

        if (reg.remove(p))
        {
            System.out.println("\nPerson removed");
        }
        else
        {
            System.out.println("\nCan't remove person");
        }

        // skriv ut register till angiven fil

        if (reg.save("reg2.txt"))
        {
            System.out.println("\nFile reg2.txt saved");
        }
        else
        {
            System.out.println("\nCan't open file reg2.txt");
            // System.exit(1);
        }
    }
}
